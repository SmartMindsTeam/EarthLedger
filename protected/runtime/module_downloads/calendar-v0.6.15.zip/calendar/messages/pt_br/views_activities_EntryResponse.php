<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% participará de %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% talvez participe de %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% não participará de %contentTitle%.',
);
