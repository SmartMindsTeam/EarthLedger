<?php
return array (
  'Allows the user to create new calendar entries' => 'De gebruiker mag nieuwe agenda-items maken',
  'Allows the user to edit/delete existing calendar entries' => 'De gebruiker mag bestaande agenda-items bewerken of verwijderen',
  'Create entry' => 'Maak agenda-item',
  'Manage entries' => 'Beheer items',
);
