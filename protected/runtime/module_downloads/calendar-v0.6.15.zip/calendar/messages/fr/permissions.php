<?php
return array (
  'Allows the user to create new calendar entries' => 'Autoriser l\'utilisateur à créer de nouvelles entrées dans le calendrier',
  'Allows the user to edit/delete existing calendar entries' => 'Autoriser l\'utilisateur à modifier/supprimer des entrées existantes dans le calendrier',
  'Create entry' => 'Créer une entrée',
  'Manage entries' => 'Gérer les entrées',
);
