<?php
return array (
  'Defaults' => 'Standard innstillinger',
  'Event Types' => 'Aktivitetstyper',
  'Other Calendars' => 'Andre Kalendere',
  'Snippet' => 'Snippet',
);
