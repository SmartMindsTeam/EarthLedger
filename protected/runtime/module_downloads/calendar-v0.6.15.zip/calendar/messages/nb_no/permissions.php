<?php
return array (
  'Allows the user to create new calendar entries' => 'Gir brukeren tilgang til å opprette aktiviteter',
  'Allows the user to edit/delete existing calendar entries' => 'Gir brukeren tilgang til å redigere/slette eksisterende aktiviteter',
  'Create entry' => 'Opprette',
  'Manage entries' => 'Endre',
);
