<?php
return array (
  '{displayName} canceled event \'{contentTitle}\' in space {spaceName}.' => '{displayName} evento cancellato \'{contentTitle}\' nello space {spaceName}.',
  '{displayName} canceled event \'{contentTitle}\'.' => '{displayName} evento cancellato \'{contentTitle}\'.',
  '{displayName} just updated event {contentTitle} in space {spaceName}.' => '{displayName} evento appena aggiornato  {contentTitle} nello space {spaceName}.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} evento appena aggiornato {contentTitle}.',
  '{displayName} reopened event {contentTitle} in space {spaceName}.' => '{displayName} evento riaperto {contentTitle} nello space {spaceName}.',
  '{displayName} reopened event {contentTitle}.' => '{displayName} evento riaperto {contentTitle}.',
);
