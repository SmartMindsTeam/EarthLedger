<?php
return array (
  'Calendar' => 'Caledario',
  'Receive Calendar related Notifications.' => 'Ricevi le notifiche relative al calendario.',
);
