<?php
return array (
  ':count attending' => ':count részt vesz',
  ':count declined' => ':count nem vesz részt',
  ':count maybe' => ':count talán',
  'Participants:' => 'Résztvevők:',
);
