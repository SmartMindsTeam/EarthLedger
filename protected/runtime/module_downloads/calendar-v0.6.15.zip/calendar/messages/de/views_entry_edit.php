<?php
return array (
  '<strong>Create</strong> event' => 'Termin <strong>erstellen</strong>',
  '<strong>Edit</strong> event' => 'Termin <strong>bearbeiten</strong>',
  'Basic' => 'Allgemein',
  'Everybody can participate' => 'Jeder darf teilnehmen',
  'Files' => 'Dateien',
  'No participants' => 'Keine Teilnehmer',
  'Participation' => 'Teilnahmemodus',
  'Select event type...' => 'Wähle Kategorie',
  'Title' => 'Titel',
);
