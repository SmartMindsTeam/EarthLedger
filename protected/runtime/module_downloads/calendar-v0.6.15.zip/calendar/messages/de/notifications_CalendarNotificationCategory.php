<?php
return array (
  'Calendar' => 'Kalender',
  'Receive Calendar related Notifications.' => 'Erhalte Kalender-Benachrichtigungen ',
);
