
* Install module “Custom Post” in your humhub application   
    o	Go to Admin menu->modules  
    o	Click enable under Custom Post 
