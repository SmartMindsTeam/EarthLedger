
<div class="panel panel-default">
	Land :<?=$land_count?>
	Air :<?=$air_count?>
	Ocean :<?=$ocean_count?>
	River :<?=$river_count?>
</div>