<?php

use humhub\modules\custom_post\Assets;

Assets::register($this);

?>
<div class="container-fluid">
    <div class="row">
<div class="col-sm-10 col-sm-offset-1 login-min-height">
  <div class="donate-box">
        <?php echo $content; ?>
</div>
</div>
    </div>
</div>

