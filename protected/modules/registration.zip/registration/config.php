<?php

return [
	'id' => 'registration',
	'class' => 'humhub\modules\registration\Module',
	'namespace' => 'humhub\modules\registration',
	'events' => [

	],
];
